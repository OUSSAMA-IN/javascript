# Respuestas a las preguntas teóricas

## Ejercicio T1

## Ejercicio T2
