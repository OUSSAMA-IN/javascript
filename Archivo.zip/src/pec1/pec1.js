export function ex1(r) {
}
 
export function ex2(r) {
} 