# Respostes a les preguntes teòriques

## Exercici T1

## Exercici T2
